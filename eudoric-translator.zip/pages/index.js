
import EudoricTranslator from '../components/Translator';

export default function Home() {
  return <EudoricTranslator />;
}
