import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const EUDORIC_MAP = {
  A: { glyph: "𐌀", name: "Aelun", meaning: "Light, creation" },
  B: { glyph: "𐌱", name: "Bravael", meaning: "Earth, foundation" },
  C: { glyph: "𐌲", name: "Cyrain", meaning: "Cycle, rebirth" },
  D: { glyph: "𐌳", name: "Dovrek", meaning: "Death, transformation" },
  E: { glyph: "𐌴", name: "Elarai", meaning: "Wisdom, memory" },
  F: { glyph: "𐌵", name: "Fysur", meaning: "Flame, energy" },
  G: { glyph: "𐌶", name: "Ghaal", meaning: "Protection, strength" },
  H: { glyph: "𐌷", name: "Hekari", meaning: "Wind, swiftness" },
  I: { glyph: "𐌹", name: "Isari", meaning: "Soul, insight" },
  J: { glyph: "𐌾", name: "Jovien", meaning: "Justice, judgment" },
  K: { glyph: "𐌺", name: "Kaevra", meaning: "Stone, resilience" },
  L: { glyph: "𐌻", name: "Luneth", meaning: "Moon, mystery" },
  M: { glyph: "𐌼", name: "Maelra", meaning: "Sea, emotion" },
  N: { glyph: "𐌽", name: "Nyxul", meaning: "Night, shadow" },
  O: { glyph: "𐍉", name: "Oralis", meaning: "Sun, revelation" },
  P: { glyph: "𐍀", name: "Prython", meaning: "Power, divine force" },
  Q: { glyph: "𐌶𐌴", name: "Quelari", meaning: "Silence, balance" },
  R: { glyph: "𐍂", name: "Raemir", meaning: "Royalty, destiny" },
  S: { glyph: "𐍃", name: "Solmar", meaning: "Star, hope" },
  T: { glyph: "𐍄", name: "Taziel", meaning: "Time, patience" },
  U: { glyph: "𐌿", name: "Ur’kai", meaning: "Unity, breath" },
  V: { glyph: "𐍅", name: "Valkaen", meaning: "War, divine wrath" },
  W: { glyph: "𐍄𐌴", name: "Weymir", meaning: "Will, guidance" },
  X: { glyph: "𐌺𐍃", name: "Xalar", meaning: "Crossroads, decision" },
  Y: { glyph: "𐌾𐌴", name: "Yserin", meaning: "Youth, renewal" },
  Z: { glyph: "𐍆", name: "Zereth", meaning: "Endings, prophecy" },
};

export default function EudoricTranslator() {
  const [input, setInput] = useState("");
  const [result, setResult] = useState([]);

  const translate = () => {
    const chars = input.toUpperCase().split("").filter(c => EUDORIC_MAP[c]);
    const translated = chars.map(c => ({
      letter: c,
      ...EUDORIC_MAP[c]
    }));
    setResult(translated);
  };

  return (
    <div className="p-4 max-w-2xl mx-auto space-y-4">
      <h1 className="text-2xl font-bold">Eudoric Name Translator</h1>
      <Input
        placeholder="Enter a name (e.g., Eudoria)"
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />
      <Button onClick={translate}>Translate</Button>
      <div className="space-y-2">
        {result.map((item, idx) => (
          <Card key={idx}>
            <CardContent className="p-2">
              <div className="text-xl">{item.letter} → {item.glyph}</div>
              <div className="text-sm italic">{item.name} — {item.meaning}</div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
